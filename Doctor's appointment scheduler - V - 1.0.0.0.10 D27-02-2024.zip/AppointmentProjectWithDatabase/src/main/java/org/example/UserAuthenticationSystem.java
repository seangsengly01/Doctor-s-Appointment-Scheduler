package org.example;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import static org.example.Utils.*;

public class UserAuthenticationSystem {
    static Scanner scanner = new Scanner(System.in);
    static Map<String, Integer> loginAttempts = new HashMap<>();
    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo01", "root", "Demo@123")) {
            createTablesIfNotExists(connection);
            while (true) {
                System.out.println("1. Register\n2. Login\n3. Reset Password\n4. Exit");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
                switch (choice) {
                    case 1:
                        registerUser(connection);
                        break;
                    case 2:
                        loginUser(connection);
                        break;
                    case 3:
                        resetPassword(connection);
                        break;
                    case 4:
                        System.out.println("Exiting program.");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static void createTablesIfNotExists(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            // Create doctors table
            String createDoctorTableQuery = "CREATE TABLE IF NOT EXISTS doctors (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "email VARCHAR(255) UNIQUE," +
                    "name VARCHAR(255)," +
                    "specialty VARCHAR(255)," +
                    "contact_details VARCHAR(255)," +
                    "bio TEXT," +
                    "password VARCHAR(255))";
            statement.execute(createDoctorTableQuery);

            // Create availability table
            String createAvailabilityTableQuery = "CREATE TABLE IF NOT EXISTS availability (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "doctor_id INT," +
                    "doctor_email VARCHAR(255)," +
                    "doctor_name VARCHAR(255)," +
                    "doctor_specialty VARCHAR(255)," +
                    "start_time TIMESTAMP," +
                    "end_time TIMESTAMP," +
                    "FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE)";
            statement.execute(createAvailabilityTableQuery);

            // Create users table
            String createUsersTableQuery = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "email VARCHAR(255) UNIQUE," +
                    "name VARCHAR(255)," +
                    "password VARCHAR(255))";
            statement.execute(createUsersTableQuery);

            // Create password_reset_attempts table
            String createPasswordResetAttemptsTableQuery = "CREATE TABLE IF NOT EXISTS password_reset_attempts (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "email VARCHAR(255) UNIQUE," +
                    "reset_date DATE)";
            statement.execute(createPasswordResetAttemptsTableQuery);

        }
    }

    private static void registerUser(Connection connection) {
        System.out.println("User Registration:");
        System.out.print("Enter name (uppercase, min 6, max 25 chars, no numbers/special chars, can have spaces): ");
        String name = scanner.nextLine().toUpperCase();
        // Validate name
        if (!name.matches("^[A-Z][A-Za-z\\s]{5,24}$")) {
            System.out.println("Invalid name format. Please try again.");
            return;
        }
        System.out.print("Enter email (should have @gmail.com): ");
        String email = scanner.nextLine();
        // Validate email
        if (!email.matches(".+@gmail\\.com")) {
            System.out.println("Invalid email format. Please try again.");
            return;
        }
        // Check for duplicate email
        if (isEmailExists(connection, email)) {
            System.out.println("Email already exists. Please use a different email.");
            return;
        }
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        // Validate password strength
        if (!isValidPassword(password)) {
            System.out.println("Weak password. Please use a stronger password.");
            return;
        }
        // Register user in the database
        addUserToDatabase(connection, name, email, password); // Pass name, email, and password
        System.out.println("Registration successful!");
    }

    private static void addUserToDatabase(Connection connection, String name, String email, String password) {
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO users (name, email, password) VALUES (?, ?, ?)")) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, password);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static boolean isValidPassword(String password) {
        // Implement your password strength requirements here
        // For simplicity, let's say the password should be at least 8 characters long
        return password.length() >= 8;
    }
}
